from PIL import Image

colorList = ["White", "Blue", "Red", "Yellow", "Cyan", "Magenta"]
colorCodes = [(1, 1, 1), (0, 0, 1), (1, 0, 0), (1, 1, 0), (0, 1, 1), (1, 0, 1)]

def change_color(skinName, output_path):
    for i in range(len(colorList)):
        img = Image.open(f"{output_path}{skinName}/{skinName}Green.png").convert("RGBA")
        width, height = img.size
        color = colorList[i]
        rC, gC, bC = colorCodes[i]
        print(f"Changing {skinName} to {color}...")
        for x in range(width):
            for y in range(height):
                r, g, b, a = img.getpixel((x, y))
                if (r, g, b) != (255, 255, 255):
                    if g > r and g > b:
                        #grayScale = int((r + g + b) / 3)
                        #r, g, b = grayScale, grayScale, grayScale
                        r, g, b = g*rC, g*gC, g*bC
                    img.putpixel((x, y), (r, g, b, a))
                else:
                    img.putpixel((x, y), (255, 255, 255, 0))

        img.save(f"{output_path}{skinName}/{skinName}{color}.png")

change_color("Dino", 'assets/')