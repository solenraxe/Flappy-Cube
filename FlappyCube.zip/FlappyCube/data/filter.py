import json

bad_words = []
with open("data/bad_words.json", "r") as f:
    bad_words = json.load(f)

new_bad_words = []
for word in bad_words:
    if len(word) == 3:
        new_bad_words.append(word.lower())

with open("data/bad_words.json", "w") as f:
    json.dump(new_bad_words, f, indent=4)